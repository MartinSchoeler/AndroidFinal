package com.example.tecnicoti.projeton1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.suitebuilder.annotation.MediumTest;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Spinner spDepu;
    private TextView tvPartido;
    private TextView tvFone;
    private TextView tvNome;
    private TextView tvNasc;
    private TextView tvHistoria;
    private ImageView ivFoto;
    private String item;

    private Button btnOK;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spDepu = (Spinner) findViewById(R.id.spDepu);
        tvNome = (TextView) findViewById(R.id.tvNome);
        tvFone = (TextView) findViewById(R.id.tvFone);
        tvNasc = (TextView) findViewById(R.id.tvNasc);
        tvPartido = (TextView) findViewById(R.id.tvPartido);
        tvHistoria = (TextView) findViewById(R.id.tvHistoria);
        ivFoto = (ImageView) findViewById(R.id.ivFoto);
        btnOK = (Button) findViewById(R.id.btnOK);

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                item = (String) spDepu.getSelectedItem();

                if(item.equals("Danrlei")){
                    ivFoto.setImageResource(R.drawable.dan );
                    tvNome.setText("Danrlei De Deus Hinterholz");
                    tvNasc.setText("18 de abril de 1973");
                    tvPartido.setText("PSD");
                    tvFone.setText("(51) 3215-5566");
                    tvHistoria.setText("Ex-jogador do Grêmio, Atlético-MG e da seleção brasileira, o deputado Danrlei de Deus Hinterholtz está em seu 1º mandato como deputado federal. 4º mais votado no Rio Grande do Sul, Danrlei, que possui base política em Porto Alegre, é titular da Comissão de Turismo e Desporto da Câmara dos Deputados.");


                }else if (item.equals("Luciana")){
                    ivFoto.setImageResource(R.drawable.lu);
                    tvNasc.setText("17 de janeiro de 1971");
                    tvNome.setText("Luciana Genro");
                    tvPartido.setText("PT, PSOL");
                    tvFone.setText("contato@lucianagenro.com.br");
                    tvHistoria.setText("Deputada federal pelo  Rio Grande do Sul durante o período 1 de fevereiro de 2003 até 31 de janeiro de 2011 (2 mandatos consecutivos) Deputada estadual do  Rio Grande do Sul Durante o período 1 de janeiro de 1995 até 31 de dezembro de 2002");

                }else if (item.equals("Onyx")){
                    ivFoto.setImageResource(R.drawable.ony);
                    tvNome.setText(" Dornelles Lorernzoni");
                    tvNasc.setText("3 de outubro de 1954");
                    tvPartido.setText("DEM");
                    tvFone.setText("(51) 3215-5828");
                    tvHistoria.setText("Deputado federal pelo Rio Grande do Sul no Período, 1 de fevereiro de 2003 até a atualidade.");

                }
            }
        });








    }
}
