package com.example.tecnicoti.projeton1;

import java.util.ArrayList;

/**
 * Created by tecnico.ti on 08/08/2016.
 */
public class Politico {
    private ArrayList<String> listaTemp;
    private String nome;
    private String dataNasc;
    private String partido;
    private String contato;
    private String sobre;

    public ArrayList<String> getListaTemp() {
        return listaTemp;
    }

    public void setListaTemp(ArrayList<String> listaTemp) {
        this.listaTemp = listaTemp;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    public String getPartido() {
        return partido;
    }

    public void setPartido(String partido) {
        this.partido = partido;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getSobre() {
        return sobre;
    }

    public void setSobre(String sobre) {
        this.sobre = sobre;
    }

    public Politico() {

    }

    public void popularClasse(){
        if (!listaTemp.isEmpty()) {
            nome = listaTemp.get(0).toString();
            dataNasc = listaTemp.get(1).toString();
            partido = listaTemp.get(2).toString();
            contato = listaTemp.get(3).toString();
            sobre = listaTemp.get(4).toString();

            listaTemp.clear();
        }
    }

    @Override
    public String toString() {
        return "Politico{" +
                "listaTemp=" + listaTemp +
                ", nome='" + nome + '\'' +
                ", dataNasc='" + dataNasc + '\'' +
                ", partido='" + partido + '\'' +
                ", contato='" + contato + '\'' +
                ", sobre='" + sobre + '\'' +
                '}';
    }
}
