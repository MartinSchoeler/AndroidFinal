package com.example.tecnicoti.projeton1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;

public class Main2Activity extends AppCompatActivity {

    private EditText etPesquisa;
    private ListView lvCandidatos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


    }
}
